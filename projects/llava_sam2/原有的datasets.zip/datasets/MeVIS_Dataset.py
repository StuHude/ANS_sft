from .ReVOS_Dataset import VideoReVOSDataset


class VideoMeVISDataset(VideoReVOSDataset):
    pass
